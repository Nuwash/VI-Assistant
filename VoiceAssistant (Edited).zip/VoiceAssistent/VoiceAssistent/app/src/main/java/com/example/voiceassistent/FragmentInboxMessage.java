/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:44 PM
 *
 *
 */

package com.example.voiceassistent;


import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Locale;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentInboxMessage extends Fragment {

    // for TTS......//
    private TextToSpeech toSpeech;
    private static String Voice;
    private int result;

    private static FragmentInboxMessage inst;
    ArrayList<String> smsMessageList = new ArrayList<String>();
    ListView smsListview;
    ArrayAdapter arrayAdapter;

    public static FragmentInboxMessage instance(){return inst;}

    @Override
    public void onStart() {
        super.onStart();
        inst = this;
    }

    public FragmentInboxMessage() {
        // Required empty public constructor
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_fragment_inbox_message, container, false);

        // for TTS......Speaker //
        Speaker();
        smsListview = view.findViewById(R.id.SmSList);

        arrayAdapter = new ArrayAdapter<String>(getActivity(),R.layout.my_list,smsMessageList);
        smsListview.setAdapter(arrayAdapter);

        smsListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String Text = (smsListview.getItemAtPosition(i).toString());
                Speak(Text);
            }
        });

        if (ContextCompat.checkSelfPermission(getActivity(),"android.permission.READ_SMS") == PackageManager.PERMISSION_GRANTED)
        {
            refreshSmsInbox();
        }
        else
        {
            final int REQUEST_CODE_ASK_PERMISSION = 123;
            ActivityCompat.requestPermissions(getActivity(),new String[]{"android.permission.READ_SMS"},REQUEST_CODE_ASK_PERMISSION);
        }

        // Inflate the layout for this fragment
        return view;

    }

    //...For Speak....///

    private void Speaker()
    {
        toSpeech = new TextToSpeech(getActivity(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

                if (status == TextToSpeech.SUCCESS) {
                    result = toSpeech.setLanguage(Locale.US);
                    Speak(Voice);

                } else {
                    Toast.makeText(getActivity(), "Feature is not support in your device", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void Speak(String text) {

        toSpeech.setPitch(0.6f);
        toSpeech.setSpeechRate(1.0f);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            toSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        } else {
            toSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }
    }


    //  Refresh Message Inbox

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void refreshSmsInbox() {
        ContentResolver contentResolver = getActivity().getContentResolver();
        Cursor smsInboxCursor = contentResolver.query(Uri.parse("content://sms/inbox"),null,null,null);
        int inboxBody = smsInboxCursor.getColumnIndex("body");
        int inboxAddress = smsInboxCursor.getColumnIndex("Address");
        if (inboxBody<0 || !smsInboxCursor.moveToFirst()) return;
        arrayAdapter.clear();

        do {
            String str = "SMS From: " + smsInboxCursor.getString(inboxAddress) + "\n" + smsInboxCursor.getString(inboxBody) + "\n";
            arrayAdapter.add(str);


        }while (smsInboxCursor.moveToNext());

    }

    public void updteList(final String smsMessage)
    {
        arrayAdapter.insert(smsMessage,0);
        arrayAdapter.notifyDataSetChanged();
    }

    @Override
    public void onPause() {
        if (toSpeech != null || toSpeech.isSpeaking()) {
            toSpeech.stop();
            toSpeech.shutdown();
        }
        super.onPause();
    }
}
