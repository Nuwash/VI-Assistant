/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:44 PM
 *
 *
 */

package com.example.voiceassistent;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;

public class EmailSending extends AppCompatActivity {

    EditText address,subject,message;
    Button Send;

    private static String speakText = "";
    private TextToSpeech toSpeech;
    private int result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setElevation(0f);
        setContentView(R.layout.activity_email_sending);

        setTitle("Email");

        address = findViewById(R.id.addrerssID);
        address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent address = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                address.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                address.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH);
                startActivityForResult(address,10);
            }
        });

        subject = findViewById(R.id.subjectID);
        subject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent subject = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                subject.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                subject.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.ENGLISH);
                startActivityForResult(subject,20);
            }
        });

        message = findViewById(R.id.messageID);
        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent message = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                message.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                message.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.ENGLISH);
                startActivityForResult(message,30);
            }
        });

        Send = findViewById(R.id.sendID);
        Send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!address.getText().toString().equals("")||!subject.getText().toString().equals("")||!message.getText().toString().equals(""))
                {
                    sendEmail();
                }

            }
        });

    }

    private void Speaker()
    {
        toSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {

                if (i == TextToSpeech.SUCCESS)
                {
                    result = toSpeech.setLanguage(Locale.US);
                    Speek(speakText);
                }
                else
                {
                    Toast.makeText(EmailSending.this, "Feature is not support in your device", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void Speek(String message)
    {

        toSpeech.setPitch(0.6f);
        toSpeech.setSpeechRate(1.0f);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            toSpeech.speak(message,TextToSpeech.QUEUE_FLUSH,null,null);
        }
        else
            toSpeech.speak(message,TextToSpeech.QUEUE_FLUSH,null);
    }

    private void sendEmail()
    {
        String recepientList = address.getText().toString();
        String[] recepients = recepientList.split(",");
        String Subject = subject.getText().toString();
        String Message = message.getText().toString();

        if (!address.getText().toString().equals("")||!subject.getText().toString().equals("")||!message.getText().toString().equals(""))
        {
            Intent emailIntent = new Intent(Intent.ACTION_SEND);
            emailIntent.setData(Uri.parse("mailto:"));
            emailIntent.setType("text/plain");
            emailIntent.putExtra(Intent.EXTRA_EMAIL, recepients);
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, Subject);
            emailIntent.putExtra(Intent.EXTRA_TEXT, Message);
            startActivity(emailIntent);
        }
        else
        {
            Toast.makeText(this, "Please Input All the EditText", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null)
        {
            switch (requestCode)
            {
                case 10:
                    ArrayList<String> Address = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    address.setText(Address.get(0).trim());
                    if (!address.equals(""))
                    {
                        speakText = "Enter Subject";
                        Speaker();
                    }
                    subject.requestFocus();
                    break;
                case 20:
                    ArrayList<String> Subject = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    subject.setText(Subject.get(0).trim());
                    if (!subject.equals(""))
                    {
                        speakText = "Enter Message";
                        Speaker();
                    }
                    message.requestFocus();
                    break;
                case 30:
                    ArrayList<String> Message = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    message.setText(Message.get(0).trim());
                    speakText = "Preass the send Button";
                    Speaker();
                    break;
            }
        }
    }
}
