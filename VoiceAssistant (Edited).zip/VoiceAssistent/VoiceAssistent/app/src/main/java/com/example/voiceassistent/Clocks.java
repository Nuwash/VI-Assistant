/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 9/7/19 11:38 AM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 9/7/19 11:38 AM
 *
 *
 */

package com.example.voiceassistent;

import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.format.DateUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;
import java.util.Locale;

public class Clocks extends AppCompatActivity {

    private TextView Time, Date;

    private TextToSpeech toSpeech;
    private String messageText;
    private int result;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clocks);

        Time = findViewById(R.id.timeID);
        Date = findViewById(R.id.dateID);

        java.util.Date now = new Date();
        String time = DateUtils.formatDateTime(Clocks.this, now.getTime(), DateUtils.FORMAT_SHOW_TIME);

        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd ");
        String date = df.format(c.getTime());

        Time.setText(time);
        Date.setText(date);

        messageText = "এখন সময় " + time + "এবং তারিখ " + date;
        Speaker();


    }

    private void Speaker() {
        toSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {

                if (i == TextToSpeech.SUCCESS) {
                    result = toSpeech.setLanguage(Locale.US);
                    Speek(messageText);
                } else {
                    Toast.makeText(Clocks.this, "Feature is not support in your device", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void Speek(String message) {

        toSpeech.setPitch(0.6f);
        toSpeech.setSpeechRate(1.0f);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            toSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null, null);
        } else
            toSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    protected void onPause() {
        if (toSpeech != null || toSpeech.isSpeaking()) {
            toSpeech.stop();
            toSpeech.shutdown();
        }
        super.onPause();
    }
}
