/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:44 PM
 *
 *
 */

package com.example.voiceassistent;


import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentContactList extends Fragment {


    private RecyclerView recyclerViewFragment;
    String [] Name,countryName;
    FragmentContactListAdapter fragmentContactListAdapter;

    private TextToSpeech toSpeech;

    public FragmentContactList() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_fragment_contact_list, container, false);

        recyclerViewFragment = view.findViewById(R.id.myRecycleViewFramentID);
       // Name = getResources().getStringArray(R.array.bikeName);
       // countryName = getResources().getStringArray(R.array.bikeCountryName);

        // myRecycleViewFragmentAdapter = new MyRecycleViewFragmentAdapter(getActivity(),Name,countryName);
        fragmentContactListAdapter = new FragmentContactListAdapter(getActivity(),getContacts());
        recyclerViewFragment.setAdapter(fragmentContactListAdapter);
        recyclerViewFragment.setLayoutManager(new LinearLayoutManager(getActivity()));


        // Inflate the layout for this fragment
        return view;
    }

    private List<FragmentContactListModel> getContacts(){

        List<FragmentContactListModel> list = new ArrayList<>();
        Cursor cursor = getActivity().getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null,null,null,ContactsContract.Contacts.DISPLAY_NAME );


        cursor.moveToFirst();
        while (cursor.moveToNext())
        {
            list.add(new FragmentContactListModel(cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            )),cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))));
        }
        return list;
    }

  /*  @Override
    public void onPause() {
        if (toSpeech != null || toSpeech.isSpeaking())
        {
            toSpeech.stop();
            toSpeech.shutdown();
        }
        super.onPause();
    }*/
}
