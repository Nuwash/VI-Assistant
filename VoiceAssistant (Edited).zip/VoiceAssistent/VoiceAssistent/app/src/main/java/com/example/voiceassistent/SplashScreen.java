/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:44 PM
 *
 *
 */

package com.example.voiceassistent;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class SplashScreen extends AppCompatActivity {

    private TextView welcomeText;
    private Animation fade,layout_fade,layout_fade_out;

    // For TTS
    private TextToSpeech toSpeech;
    private int result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setElevation(0f);
        setContentView(R.layout.activity_splash_screen);

        welcomeText = findViewById(R.id.welcomeTextID);
        fade = AnimationUtils.loadAnimation(this,R.anim.fade);
        layout_fade = AnimationUtils.loadAnimation(this,R.anim.layout_fade);
        layout_fade_out = AnimationUtils.loadAnimation(this,R.anim.layout_fade_out);

        welcomeText.setAnimation(fade);


        Speaker();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashScreen.this,Home.class);
                startActivity(intent);
                overridePendingTransition(R.anim.layout_fade,R.anim.layout_fade);
                finish();
            }
        },3*1000);

    }

    private void Speaker()
    {
        toSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {

                if (i == TextToSpeech.SUCCESS)
                {
                    result = toSpeech.setLanguage(Locale.US);
                    Speek();
                }
                else
                {
                    Toast.makeText(SplashScreen.this, "Feature is not support in your device", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void Speek()
    {

        String text = welcomeText.getText().toString();
        toSpeech.setPitch(0.6f);
        toSpeech.setSpeechRate(1.0f);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            toSpeech.speak(text,TextToSpeech.QUEUE_FLUSH,null,null);
        }
        else
            toSpeech.speak(text,TextToSpeech.QUEUE_FLUSH,null);
    }


}
