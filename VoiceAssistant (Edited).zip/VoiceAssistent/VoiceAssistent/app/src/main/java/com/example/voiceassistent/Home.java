/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:44 PM
 *
 *
 */

package com.example.voiceassistent;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;

public class Home extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {

    private LinearLayout callLog,message,battery,email,clock,voice;

    private static String messageText = "";

    private TextToSpeech toSpeech;
    private int result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        callLog = findViewById(R.id.callLogCardview);
        callLog.setOnClickListener(this);
        callLog.setOnLongClickListener(this);

        message = findViewById(R.id.messageCardview);
        message.setOnClickListener(this);
        message.setOnLongClickListener(this);

        battery = findViewById(R.id.batteryCardview);
        battery.setOnClickListener(this);
        battery.setOnLongClickListener(this);

        email = findViewById(R.id.emilCardview);
        email.setOnClickListener(this);
        email.setOnLongClickListener(this);

        clock = findViewById(R.id.clockCardview);
        clock.setOnClickListener(this);
        clock.setOnLongClickListener(this);

        voice = findViewById(R.id.vcCardview);
        voice.setOnClickListener(this);
        voice.setOnLongClickListener(this);
        messageText = "I'm ready";

        messageText = "প্রথম সারির প্রথম কলাম call log প্রথম সারির দ্বিতীয়  কলাম message দ্বিতীয়  সারির প্রথম কলাম battery  দ্বিতীয়  সারির দ্বিতীয়  কলাম email তৃতীয় সারির প্রথম কলাম clock তৃতীয় সারির দ্বিতীয় কলাম voice commend";
        Speaker();


    }

    private void Speaker()
    {
        toSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {

                if (i == TextToSpeech.SUCCESS)
                {
                    result = toSpeech.setLanguage(Locale.US);
                    Speak(messageText);
                }
                else
                {
                    Toast.makeText(Home.this, "Feature is not support in your device", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void Speak(String message)
    {

        toSpeech.setPitch(0.6f);
        toSpeech.setSpeechRate(1.0f);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            toSpeech.speak(message,TextToSpeech.QUEUE_FLUSH,null,null);
        }
        else
            toSpeech.speak(message,TextToSpeech.QUEUE_FLUSH,null);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.batteryCardview:
                messageText = "You click for Battery Chack up";
                Speaker();
                break;

            case R.id.messageCardview:
                messageText = "You click for Message";
                Speaker();
                break;

            case R.id.callLogCardview:
                messageText = "You click for Call";
                Speaker();
                break;

            case R.id.emilCardview:
                messageText = "You click for Send Email";
                Speaker();
                break;

            case R.id.clockCardview:
                messageText = "You Click for Clock";
                Speaker();
                break;

            case R.id.vcCardview:

                messageText = "You Click for Voice Command";
                Speaker();

                break;

        }
    }

    private void clockActivity()
    {
        Intent intent = new Intent(this,Clocks.class);
        startActivity(intent);
    }

    private void emailActivity()
    {
        Intent intent = new Intent(this,EmailSending.class);
        startActivity(intent);
    }

    private void callLogActivity()
    {
        Intent intent = new Intent(this,CallScreenNavigation.class);
        startActivity(intent);
    }

    private void messageActivity()
    {
        Intent intent = new Intent(this,MessageScreenNavigation.class);
        startActivity(intent);
    }

    private void batteryActivity()
    {
        Intent intent = new Intent(this,Battery.class);
        startActivity(intent);
    }

    private void voiceCommandActivity()
    {
        Intent voiceCommand = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        voiceCommand.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        voiceCommand.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        voiceCommand.putExtra(RecognizerIntent.EXTRA_PROMPT, "Command ");

        startActivityForResult(voiceCommand, 2);
    }

    @Override
    public boolean onLongClick(View view) {

        switch (view.getId()) {
            case R.id.batteryCardview:
                batteryActivity();
                overridePendingTransition(R.anim.layout_fade , R.anim.layout_fade);
                break;

            case R.id.messageCardview:
                messageActivity();
                overridePendingTransition(R.anim.layout_fade , R.anim.layout_fade);
                break;

            case R.id.callLogCardview:
                callLogActivity();
                overridePendingTransition(R.anim.layout_fade , R.anim.layout_fade);
                break;

            case R.id.emilCardview:
                emailActivity();
                overridePendingTransition(R.anim.layout_fade , R.anim.layout_fade);
                break;
            case R.id.clockCardview:
                clockActivity();
                overridePendingTransition(R.anim.layout_fade , R.anim.layout_fade);
                break;

            case R.id.vcCardview:
                voiceCommandActivity();
                break;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode , int resultCode , @Nullable Intent data) {
        super.onActivityResult(requestCode , resultCode , data);


        if (requestCode == 2 && resultCode == RESULT_OK && data != null)
        {
            ArrayList<String> sendMessage = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (sendMessage.get(0).toString().equals("open call"))
            {
                callLogActivity();
            }
            if (sendMessage.get(0).toString().equals("open message"))
            {
                messageActivity();
            }
            if (sendMessage.get(0).toString().equals("open battery"))
            {
                batteryActivity();
            }
            if (sendMessage.get(0).toString().equals("open email"))
            {
                emailActivity();
            }
            if (sendMessage.get(0).toString().equals("open clock"))
            {
                clockActivity();
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        if(toSpeech.isSpeaking())
            toSpeech.stop();

    }
}
