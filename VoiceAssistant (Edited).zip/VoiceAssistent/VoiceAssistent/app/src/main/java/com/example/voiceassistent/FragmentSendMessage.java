/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:44 PM
 *
 *
 */

package com.example.voiceassistent;


import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.Locale;

import static android.app.Activity.RESULT_OK;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentSendMessage extends Fragment {

    private EditText phoneNumber,messageText;

    private static String speakText = "";
    private TextToSpeech toSpeech;
    private int result;

    public FragmentSendMessage() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_fragment_send_message, container, false);


        phoneNumber = view.findViewById(R.id.phoneNumberID);
        phoneNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent Number = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                Number.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                Number.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH);
                Number.putExtra(RecognizerIntent.EXTRA_PROMPT, "I'm waiting for number");
                startActivityForResult(Number, 10);
            }
        });

        messageText = view.findViewById(R.id.messageTextID);
        messageText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent Message = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                Message.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                Message.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.ENGLISH);
                Message.putExtra(RecognizerIntent.EXTRA_PROMPT,"I'm wittin for message");
                startActivityForResult(Message,20);
            }
        });

        if (!phoneNumber.getText().toString().equals("") || !messageText.getText().toString().equals(""))
        {
            voiceSendMessage();
        }
        // Inflate the layout for this fragment
        return view;
    }


    private void Speaker()
    {
        toSpeech = new TextToSpeech(getActivity(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

                if (status == TextToSpeech.SUCCESS) {
                    result = toSpeech.setLanguage(Locale.US);
                    Speak(speakText);

                } else {
                    Toast.makeText(getActivity(), "Feature is not support in your device", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void Speak(String text) {

        toSpeech.setPitch(0.6f);
        toSpeech.setSpeechRate(1.0f);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            toSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        } else {
            toSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }
    }

    private void voiceSendMessage()
    {
        Intent voiceCommand = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        voiceCommand.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        voiceCommand.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        voiceCommand.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak Send ");

        startActivityForResult(voiceCommand, 2);
    }

    private void MyMessage()
    {
        String c_Number = phoneNumber.getText().toString().trim();
        String c_Message = messageText.getText().toString().trim();

        if (!phoneNumber.getText().toString().trim().equals("") || !messageText.getText().toString().trim().equals(""))
        {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(c_Number,null,c_Message,null,null);
            Toast.makeText(getActivity(), "Message send Successfully", Toast.LENGTH_SHORT).show();

            phoneNumber.setText("");
            messageText.setText("");
        }
        else
        {
            Toast.makeText(getActivity(), "Please Enter Your Phone Number", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode)
        {
            case 0:

                if (grantResults.length >= 0 && grantResults[0]== PackageManager.PERMISSION_GRANTED)
                {
                    MyMessage();
                }
                else
                {
                    Toast.makeText(getActivity(), "You don't have Permission ", Toast.LENGTH_SHORT).show();
                }
                break;

        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null)
        {
            switch (requestCode)
            {
                case 10:
                    ArrayList<String> Phone_Number = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    phoneNumber.setText(Phone_Number.get(0).trim());
                    if (!phoneNumber.equals(""))
                    {
                        speakText = "Enter Message";
                        Speaker();
                    }
                    else
                    {
                        speakText = "Enter a number";
                        Speaker();
                    }
                    messageText.requestFocus();
                    break;
                case 20:
                    ArrayList<String> Messge_Text = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    messageText.setText(Messge_Text.get(0).trim());
                    if (!phoneNumber.equals("") && !messageText.equals(""))
                    {
                        speakText = "Speak send";
                        Speaker();
                    }
                    voiceSendMessage();
                    break;
            }
        }

        if (requestCode == 2 && resultCode == RESULT_OK && data != null)
        {
            ArrayList<String> sendMessage = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (sendMessage.get(0).toString().equals("send"))
            {
                int permissionCheck = ContextCompat.checkSelfPermission(getActivity(),"android.permission.SEND_SMS");

                if (permissionCheck == PackageManager.PERMISSION_GRANTED)
                {
                    MyMessage();
                }
                else
                {
                    final int REQUEST_CODE_ASK_PERMISSION = 123;
                    ActivityCompat.requestPermissions(getActivity(),new String[]{"android.permission.SEND_SMS"},REQUEST_CODE_ASK_PERMISSION);
                }
            }
        }
    }

}
