/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:43 PM
 *
 *
 */

package com.example.voiceassistent;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class SMSReceiver extends BroadcastReceiver {

    public static final String SMS_BUNDLE = "pdus";

    @Override
    public void onReceive(Context context, Intent intent) {

        Bundle intentExtras = intent.getExtras();
        if (intentExtras != null)
        {
            Object[] sms = (Object[]) intentExtras.get(SMS_BUNDLE);
            String smsMessageStr = "";
            for (int i =0 ; i<sms.length;i++)
            {
                SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) sms[i]);
                String smsBoddy = smsMessage.getMessageBody().toString();
                String address = smsMessage.getOriginatingAddress();

                smsMessageStr += "Sms from: "+ address + "\n";
                smsMessageStr += smsBoddy + "\n";
            }

            Toast.makeText(context,smsMessageStr, Toast.LENGTH_SHORT).show();

            FragmentInboxMessage inst = FragmentInboxMessage.instance();
            inst.updteList(smsMessageStr);
        }
    }
}
