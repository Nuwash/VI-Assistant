
/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:44 PM
 *
 *
 */

package com.example.voiceassistent;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class Battery extends AppCompatActivity {

    private BatteryReceiver batteryReceiver = new BatteryReceiver();
    private IntentFilter intentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);

    private TextToSpeech toSpeech;
    private int result;
    private TextView persentageLavel,statusLavel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setElevation(0f);
        setContentView(R.layout.activity_battery);


        statusLavel = findViewById(R.id.statusLavel);
        persentageLavel = findViewById(R.id.persentageLable);

        // Speaker
        Speaker();
    }

    private void Speaker()
    {
        toSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {

                if (i == TextToSpeech.SUCCESS)
                {
                    result = toSpeech.setLanguage(Locale.US);
                    Speek();
                }
                else
                {
                    Toast.makeText(Battery.this, "Feature is not support in your device", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void Speek()
    {
        String Persentage  = persentageLavel.getText().toString();
        String Status = statusLavel.getText().toString();
        toSpeech.setPitch(0.6f);
        toSpeech.setSpeechRate(1.0f);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            toSpeech.speak("Battery Status is "+Status+" Battery Level is "+Persentage,TextToSpeech.QUEUE_FLUSH,null,null);
        }
        else
            toSpeech.speak("Battery Level is "+Persentage,TextToSpeech.QUEUE_FLUSH,null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(batteryReceiver,intentFilter);
    }

    @Override
    protected void onPause() {
        unregisterReceiver(batteryReceiver);

        if (toSpeech != null || toSpeech.isSpeaking())
        {
            toSpeech.stop();
            toSpeech.shutdown();
        }

        super.onPause();
    }


}
