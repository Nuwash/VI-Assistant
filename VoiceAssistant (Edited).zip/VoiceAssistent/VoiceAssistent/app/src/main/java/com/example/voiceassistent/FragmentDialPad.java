/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:44 PM
 *
 *
 */

package com.example.voiceassistent;


import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.util.Locale;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentDialPad extends Fragment implements View.OnClickListener {

    private TextToSpeech toSpeech;
    private static String dialNumber = "";
    private int result;

    Button bZero, bOne, bTwo, bThree, bFour, bFive, bSix, bSeven, bEight, bNine, bStar, bHash, bDelete, bDial;
    EditText input;

    public FragmentDialPad() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_fragment_dial_pad, container, false);

        bDelete = view.findViewById(R.id.deleteID);
        bDelete.setOnClickListener(this);

        bZero = view.findViewById(R.id.buttonZeroID);
        bZero.setOnClickListener(this);

        bOne = view.findViewById(R.id.buttonOneID);
        bOne.setOnClickListener(this);

        bTwo = view.findViewById(R.id.buttonTwoID);
        bTwo.setOnClickListener(this);

        bThree = view.findViewById(R.id.buttonThreeID);
        bThree.setOnClickListener(this);

        bFour = view.findViewById(R.id.buttonFourID);
        bFour.setOnClickListener(this);

        bFive = view.findViewById(R.id.buttonFiveID);
        bFive.setOnClickListener(this);

        bSix = view.findViewById(R.id.buttonSixID);
        bSix.setOnClickListener(this);

        bSeven = view.findViewById(R.id.buttonSevenID);
        bSeven.setOnClickListener(this);

        bEight = view.findViewById(R.id.buttonEightID);
        bEight.setOnClickListener(this);

        bNine = view.findViewById(R.id.buttonNineID);
        bNine.setOnClickListener(this);

        bStar = view.findViewById(R.id.buttonStarID);
        bStar.setOnClickListener(this);

        bHash = view.findViewById(R.id.buttonHashID);
        bHash.setOnClickListener(this);

        bDial = view.findViewById(R.id.buttonDialID);
        bDial.setOnClickListener(this);

        input = view.findViewById(R.id.editTextNumber);
        // Inflate the layout for this fragment
        return view;
    }

    // Speaker......

    private void speaker()
    {
        toSpeech = new TextToSpeech(getActivity(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

                if (status == TextToSpeech.SUCCESS)
                {
                    result = toSpeech.setLanguage(Locale.US);
                    Speak(dialNumber);;

                }
                else
                {
                    Toast.makeText(getActivity(), "Feature is not support in your device", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void Speak(String text) {

        toSpeech.setPitch(0.6f);
        toSpeech.setSpeechRate(1.0f);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            toSpeech.speak(text,TextToSpeech.QUEUE_FLUSH,null,null);
        }
        else
        {toSpeech.speak(text,TextToSpeech.QUEUE_FLUSH,null);}
    }


    @Override
    public void onClick(View view)
    {
        switch (view.getId()) {
            case R.id.buttonOneID:
                onButtonClick(bOne, input, "1");
                dialNumber = "1";
                speaker();
                break;
            case R.id.buttonTwoID:
                onButtonClick(bTwo, input, "2");
                dialNumber = "2";
                speaker();
                break;
            case R.id.buttonThreeID:
                onButtonClick(bThree, input, "3");
                dialNumber = "3";
                speaker();
                break;
            case R.id.buttonFourID:
                onButtonClick(bFour, input, "4");
                dialNumber = "4";
                speaker();
                break;
            case R.id.buttonFiveID:
                onButtonClick(bFive, input, "5");
                dialNumber = "5";
                speaker();
                break;
            case R.id.buttonSixID:
                onButtonClick(bSix, input, "6");
                dialNumber = "6";
                speaker();
                break;
            case R.id.buttonSevenID:
                onButtonClick(bSeven, input, "7");
                dialNumber = "7";
                speaker();
                break;
            case R.id.buttonEightID:
                onButtonClick(bEight, input, "8");
                dialNumber = "8";
                speaker();
                break;
            case R.id.buttonNineID:
                onButtonClick(bNine, input, "9");
                dialNumber = "9";
                speaker();
                break;
            case R.id.buttonZeroID:
                onButtonClick(bZero, input, "0");
                dialNumber = "0";
                speaker();
                break;
            case R.id.buttonStarID:
                onButtonClick(bStar, input, "*");
                dialNumber = "*";
                speaker();
                break;
            case R.id.buttonHashID:
                onButtonClick(bHash, input, "#");
                dialNumber = "#";
                speaker();
                break;
            case R.id.deleteID:
                input.setText("");
                dialNumber = "The number is clear";
                speaker();
                break;
            case R.id.buttonDialID:
                if (input.getText().length()<3)
                {
                    dialNumber = "number in Invalid";
                    speaker();
                }
                else
                {
                    dialNumber = "Call is prossesing";
                    speaker();
                    String hash = input.getText().toString();
                    Intent intent = new Intent(Intent.ACTION_CALL);
                    if (hash.contains("#"))
                    {
                        hash.replace("#","#");
                    }
                    intent.setData(Uri.parse("tel:" + hash ));
                    int permissionCheck = ContextCompat.checkSelfPermission(getActivity(),"android.permission.CALL_PHONE");

                    if (permissionCheck == PackageManager.PERMISSION_GRANTED)
                    {
                        startActivity(intent);
                    }
                    else
                    {
                        final int REQUEST_CODE_ASK_PERMISSION = 123;
                        ActivityCompat.requestPermissions(getActivity(),new String[]{"android.permission.CALL_PHONE"},REQUEST_CODE_ASK_PERMISSION);
                    }

                    input.setText("");
                }
                break;
        }
    }

    public void onButtonClick(Button button,EditText inputNumber,String number  )
    {
        String cache = input.getText().toString();
        inputNumber.setText(   cache + number);
    }
}
