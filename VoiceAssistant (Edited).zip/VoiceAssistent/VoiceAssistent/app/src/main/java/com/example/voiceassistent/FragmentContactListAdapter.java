/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:44 PM
 *
 *
 */

package com.example.voiceassistent;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

public class FragmentContactListAdapter extends RecyclerView.Adapter<FragmentContactListAdapter.MyFragmentViewHolder> {


    private Context context;
    private List<FragmentContactListModel> fragmentContactListModelList;

    public FragmentContactListAdapter(Context context, List<FragmentContactListModel> fragmentContactListModelList) {
        this.context = context;
        this.fragmentContactListModelList = fragmentContactListModelList;
    }

    @NonNull
    @Override
    public MyFragmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.semple_fragment_contactlist, parent, false);
        return new MyFragmentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyFragmentViewHolder holder, int position) {

        holder.nameTextView.setText(fragmentContactListModelList.get(position).getName());
        holder.numberTextView.setText(fragmentContactListModelList.get(position).getNumber());
    }

    @Override
    public int getItemCount() {
        return fragmentContactListModelList.size();
    }


    class MyFragmentViewHolder extends RecyclerView.ViewHolder {

        // for TTS......//
        private TextToSpeech toSpeech;
        private  String Voice;
        private int result;
        //-------------//

        TextView nameTextView, numberTextView;

        public MyFragmentViewHolder(@NonNull View itemView) {
            super(itemView);

            nameTextView = itemView.findViewById(R.id.nameID);
            numberTextView = itemView.findViewById(R.id.numberFraID);

            Speaker();

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String name = nameTextView.getText().toString();
                    String number = numberTextView.getText().toString();
                    // Speaker method
                    Speak(name + " Phone Number is " +number);
                    Toast.makeText(context, name + " Phone Number is " +number, Toast.LENGTH_SHORT).show();
                }
            });
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {

                    String number = numberTextView.getText().toString();
                    //Call method.....
                    callNumber(number);
                    return false;
                }
            });


        }

        //For TTS Speaker .........

        private void Speaker() {
            toSpeech = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int i) {

                    if (i == TextToSpeech.SUCCESS)
                    {
                        result = toSpeech.setLanguage(Locale.US);

                    }
                    else
                    {
                        Toast.makeText(context, "Feature is not support in your device", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }

        private void Speak(String message) {

            toSpeech.setPitch(0.6f);
            toSpeech.setSpeechRate(1.0f);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            {
                toSpeech.speak(message,TextToSpeech.QUEUE_FLUSH,null,null);
            }
            else
                toSpeech.speak(message,TextToSpeech.QUEUE_FLUSH,null);
        }

        //-------------------/

        // For Action_Call Intent .....................//

        private void callNumber(String number) {

            String pikNumber = numberTextView.getText().toString();
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + pikNumber));
            if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            context.startActivity(intent);
        }

        // -------------------------------//

    }

}
