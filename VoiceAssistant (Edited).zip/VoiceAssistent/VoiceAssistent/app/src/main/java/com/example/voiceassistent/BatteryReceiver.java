/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:44 PM
 *
 *
 */

package com.example.voiceassistent;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.BatteryManager;
import android.widget.ImageView;
import android.widget.TextView;

public class BatteryReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent)
    {
        TextView statusLavel = ((Battery)context).findViewById(R.id.statusLavel);
        TextView persentageLavel = ((Battery)context).findViewById(R.id.persentageLable);
        ImageView batteryImage = ((Battery)context).findViewById(R.id.batteryImageViewID);

        String action = intent.getAction();
        if (action != null && action.equals(Intent.ACTION_BATTERY_CHANGED))
        {
            // Status

            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS,-1);
            String message = "";

            switch (status)
            {
                case BatteryManager.BATTERY_STATUS_FULL:
                    message = "Full";
                    break;

                case BatteryManager.BATTERY_STATUS_CHARGING:
                    message = "Charging";
                    break;

                case BatteryManager.BATTERY_STATUS_DISCHARGING:
                    message = "Discharging";
                    break;

                case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                    message = "Not Charging";
                    break;

                case BatteryManager.BATTERY_STATUS_UNKNOWN:
                    message = "Unknown";
                    break;

            }

            statusLavel.setText(message);

            // Persentage

            int label = intent.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE,-1);
            int persentage = label * 100 / scale;
            persentageLavel.setText(persentage + "%");

            /* int persentage = intent.getIntExtra(BatteryManager.EXTRA_LEVEL,0);
            persentageLavel.setText(String.valueOf(persentage)+"%");*/

            // Image

            Resources resources = context.getResources();

            if (persentage >= 90)
            {
                batteryImage.setImageDrawable(resources.getDrawable(R.drawable.fullcharge));
            }
            else if (90 > persentage && persentage >=65)
            {
                batteryImage.setImageDrawable(resources.getDrawable(R.drawable.eighttycharge));
            }
            else if (65 > persentage && persentage >= 45)
            {
                batteryImage.setImageDrawable(resources.getDrawable(R.drawable.sixtycharge));
            }
            else if (45 > persentage && persentage >= 25)
            {
                batteryImage.setImageDrawable(resources.getDrawable(R.drawable.fourtycharge));
            }
            else
            {
                batteryImage.setImageDrawable(resources.getDrawable(R.drawable.twentycharge));
            }

        }
    }
}
