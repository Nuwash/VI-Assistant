/*
 * Created by Md.Morshed Alam ( Daffodil International University )
 *  Department of Software Engineering(SWE) on 8/27/19 12:44 PM
 *   Copyright (c) 2019 . All rights reserved.
 *   Last modified 8/27/19 12:44 PM
 *
 *
 */

package com.example.voiceassistent;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class CallScreenNavigation extends AppCompatActivity {

    com.google.android.material.tabs.TabLayout tabLayoutCall;
    ViewPager viewPagerCall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_screen_navigation);

        tabLayoutCall = findViewById(R.id.tabLayoutCall);
        viewPagerCall = findViewById(R.id.viewPagerCall);

        viewPagerCall.setAdapter(new MyPagerAdeptar(getSupportFragmentManager()));
        tabLayoutCall.setupWithViewPager(viewPagerCall);

        tabLayoutCall.addOnTabSelectedListener(new com.google.android.material.tabs.TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(com.google.android.material.tabs.TabLayout.Tab tab) {
                viewPagerCall.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(com.google.android.material.tabs.TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(com.google.android.material.tabs.TabLayout.Tab tab) {

            }
        });

    }

    class MyPagerAdeptar extends FragmentPagerAdapter
    {

        String[] text = {"Contact List","Dial Pad"};

        public MyPagerAdeptar(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {

            if (position == 0)
            {
                return new FragmentContactList();
            }

            if (position == 1)
            {
                return new FragmentDialPad();
            }

            return null;
        }

        @Override
        public int getCount() {
            return text.length;
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return text[position];
        }
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();



    }
}
